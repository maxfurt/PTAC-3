'use client'
import Link from 'next/link'
import styles from './page.module.css'

export default async function Home() {

  const req = await fetch("http://localhost:3004/alunos", {next: {revalidate:10} ,})
  const alunos = await req.json();

  return (
    <main className= {styles.main}>

      <Link href='/cadastro'>Cadastro</Link>

      {alunos.map(aluno=>(
      <div key={aluno.id}>
        <p>aluno:{aluno.nome}</p>
        <p>num_inscricao:{aluno.num_inscricao}</p>
        <p>curso:{aluno.curso}</p>

      </div>
      
        ))}
    </main>
  )
}
