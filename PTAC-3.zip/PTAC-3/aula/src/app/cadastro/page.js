'use client'
import styles from '../cadastro.module.css'
import Link from 'next/link'
import { useState } from 'react'

export default function cadastro() {
    const [nome, setNome] = useState();
    const [num_inscricao, setInscricao] = useState();
    const [curso, setCurso] = useState();

    const cadastro = () => {
        alert("cadastro")
    }

    return(
        <main className={styles.container}>
            <h1 className={styles.title}> cadastro </h1>
            <form className={styles.form} method='submit' onSubmit={cadastro}>
                <input className={styles.forminput} name='nome' type='text' placeholder='informe o nome'
                 onChange={e=>setNome(e.target.value)}></input><br/>
                 <input className={styles.forminput} name='num_inscricao' type='number' placeholder='informe o numero de inscrição'
                 onChange={e=>setInscricao(e.target.value)}></input><br/>
                 <input className={styles.forminput} name='curso' type='text' placeholder='informe o curso'
                 onChange={e=>setCurso(e.target.value)}></input><br/>

                <button className={styles.formbutton}>cadastrar</button>
            </form>
            <Link className={styles.link} href="/">voltar</Link>
        </main>
    )
}
